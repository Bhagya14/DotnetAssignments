﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_13_Abstract
{
    class salaryaccount:Demo
    {
        public salaryaccount(int accountbalance, string customername) :
            base( accountbalance, customername)
        { }
        public override void withdraw(int amt)
        {
            this.accountbalance = this.accountbalance - amt - 300;
        }
        public override void deposit(int amt)
        {
            this.accountbalance = this.accountbalance + amt + 300;
        }
    }
}

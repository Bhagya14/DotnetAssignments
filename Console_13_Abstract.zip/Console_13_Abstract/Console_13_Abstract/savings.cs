﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_13_Abstract
{
    class savings:Demo
    {
        public savings(int accountbalance, string customername) :
            base( accountbalance, customername)
        { }
        public override void withdraw(int amt)
        {
            this.accountbalance = this.accountbalance - amt;
        }
        public override void deposit(int amt)
        {
            this.accountbalance = this.accountbalance + amt;
        }
    }
}

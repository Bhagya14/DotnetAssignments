﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_13_Abstract
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter customer name:");
            string customername = Console.ReadLine();
            Console.WriteLine("enter account balance");
            int accountbalance = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("account type:");
            string accounttype = Console.ReadLine();
            Demo obj = null;
            if (accounttype == "saving")
            {
                obj = new savings(accountbalance,customername);
            }
            else if (accounttype == "current")
            {
                obj = new current( accountbalance,customername);
            }
            else if (accounttype == "demat")
            {
                obj = new current(accountbalance, customername);
            }
            else if (accounttype == "salaryaccount")
            {
                obj = new current(accountbalance, customername);
            }
            if (obj != null)
            {
                Console.WriteLine(obj.paccountid);
                Console.WriteLine(obj.pcustomername);
                int balance = obj.getbalance();
                Console.WriteLine("balance:" + balance);
                Console.WriteLine("enter amount to deposit");
                int amount = Convert.ToInt32(Console.ReadLine());
                obj.deposit(amount);
                balance = obj.getbalance();
                Console.WriteLine("balance:" + balance);
                Console.WriteLine("enter amount to withdraw:");
                amount = Convert.ToInt32(Console.ReadLine());
                obj.withdraw(amount);
                balance = obj.getbalance();
                Console.WriteLine("balance:" + balance);
                obj.Stoppayment();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_13_Abstract
{
    abstract class Demo
    {
        private int accountid;
        protected int accountbalance;
        private string customername;
        public static int count=1000;
        public Demo(int accountbalance,string customername)
        {
            this.accountid = Demo.count++;
            this.accountbalance = accountbalance;
            this.customername = customername;
        }
        public int paccountid
        {
            get
            {
                return this.paccountid;
            }
        }
        public string pcustomername
        {
            get
            {
                return this.customername;
            }
        }
        public int paccountbalance
        {
            get
            {
                return this.accountbalance;
            }
        }
        public int getbalance()
        {
            return this.accountbalance;
        }
        public void Stoppayment()
        {
            Console.WriteLine("stop payment logic");
        }
        public abstract void withdraw(int amt);

        public abstract void deposit(int amt);
        
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_interface_assignment
{
    interface IManagerEmp
    {
        int Getempid();
        int Getempexp();
        string Getempprojectdetails();
    }
}

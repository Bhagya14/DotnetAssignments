﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_task1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter num1:");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter num2:");
            int num2 = Convert.ToInt32(Console.ReadLine());
            bool flag = true;
            while (flag)
            {
                Console.WriteLine(" add -1 ,sub -2,multi -3,div -4,exit -5 ");
                int opt = Convert.ToInt32(Console.ReadLine());
                switch (opt)
                {
                    case 1:
                        {
                            int Total = num1 + num2;
                            Console.WriteLine("result:" + Total);
                            break;
                        }
                    case 2:
                        {
                            int Total = num1 - num2;
                            Console.WriteLine("result:" + Total);
                            break;
                        }
                    case 3:
                        {
                            int Total = num1 * num2;
                            Console.WriteLine("result:" + Total);
                            break;
                        }
                    case 4:
                        {
                            if (num2 > 0)
                            {
                                int total = num1 / num2;
                                Console.WriteLine("total:" + total);

                            }
                            else
                            {
                                Console.WriteLine("wrong num");
                            }
                            break;
                        }
                    case 5:
                        {
                            flag = false;
                            break;
                        }
                }
            }
        }
    }
}

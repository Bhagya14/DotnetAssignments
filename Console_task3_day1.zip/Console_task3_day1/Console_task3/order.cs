﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_task3
{
    class order
    {
        public int order_id;
        public string customer_name;
        public string Item_name;
        public int Item_qty;
        public int Item_price;
   
        public int sum()
        {
           return  (Item_price * Item_qty);
            
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_task3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("order id");
            int orderid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter customer name");
            string customer_name= Console.ReadLine();
            Console.WriteLine("enter Item_name");
            string Item_name= Console.ReadLine();
            Console.WriteLine("enter price");
            int n1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter qty");
            int n2 = Convert.ToInt32(Console.ReadLine());
            order obj = new order();
            obj.Item_price = n1;
            obj.Item_qty = n2;
            int result = obj.sum();
            Console.WriteLine(result);
            Console.ReadLine();
        }
    }
}

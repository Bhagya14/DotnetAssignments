﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_aug13th_overriding
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter customer name");
            string customername = Console.ReadLine();
            Console.WriteLine("enter item quantity");
            int itemqty = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter item price");
            int itemprice = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter order type");
            string ordertype = Console.ReadLine();
            
            if (ordertype == "order")
            {
                
                order obj = new order(customername, itemqty, itemprice);
                Console.WriteLine(obj.pcustomername);
                Console.WriteLine(obj.pitemqty);
                Console.WriteLine(obj.pitemprice);
                Console.WriteLine(obj.getordervalue());
            }
            else 
            {
                orderoverseas obj1 = new orderoverseas(customername, itemqty, itemprice);
                Console.WriteLine(obj1.getordervalue());
            }
            Console.ReadLine();
        }
    }
}

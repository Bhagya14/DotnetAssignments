﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_aug13th_overriding
{
    class order
    {
        private int orderid;
        private string customername;
        private int itemqty;
        private int itemprice;
        public static int count;
        public order(string customername,int itemqty,int itemprice)
        {
            this.orderid=order.count++;
            this.customername = customername;
            this.itemqty = itemqty;
            this.itemprice = itemprice;
        }
        public int porderid
        {
            get
            {
                return this.orderid;
            }
        }
        public string pcustomername
        {
            get
            {
                return this.customername;
            }
        }
        public int pitemqty
        {
            get
            {
                return this.itemqty;
            }
        }
        public int pitemprice
        {
            get
            {
                return this.itemprice;
            }
        }
        public virtual int getordervalue()
        {
            return this.itemprice * this.itemqty;
        }
    }
}

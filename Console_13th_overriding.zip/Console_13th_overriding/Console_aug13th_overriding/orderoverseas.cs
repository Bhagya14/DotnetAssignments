﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_aug13th_overriding
{
    class orderoverseas:order
    {
        public orderoverseas(string customername, int itemqty, int itemprice) : base(customername, itemqty, itemprice)
        {
        }
        public override int getordervalue()
        {
            return this.pitemprice * this.pitemqty + 100;
        }
    }
}

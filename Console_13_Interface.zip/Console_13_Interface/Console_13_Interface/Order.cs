﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_13_Interface
{
    class Order
    {
        private int orderid;
        private string customername;
        private Iorderproduct proobj;
        private int proqty;
        private static int count = 1000;
        public Order(string customername)
        {
            this.orderid = Order.count++;
            this.customername = customername;
        }
        public void addproduct(Iorderproduct p, int proqty)
        {
            this.proobj = p;
            this.proqty = proqty;
            Console.WriteLine("product added in order");
            int id = proobj.Getproductid();
            int price = proobj.Getprice();
            Console.WriteLine("product details: id" + id + " , price:" + price);
        }
        public int Getordervalue()
        {
            return this.proobj.Getprice() * this.proqty;
        }
        public int porderid
        {
            get
            {
                return this.orderid;
            }
        }
        public string pcustomername
        {
            get
            {
                return this.customername;
            }
        }
    }
}

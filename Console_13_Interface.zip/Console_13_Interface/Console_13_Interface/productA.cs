﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_13_Interface
{
    class productA:Iorderproduct
    {
        private int productid;
        private string productname;
        private int productprice;
        public productA(int productid, string productname, int productprice)
        {
            this.productid = productid;
            this.productname = productname;
            this.productprice = productprice;
        }

        public int Getprice()
        {
            return this.productprice;
        }

        public int Getproductid()
        {
            return this.productid;
        }
    }
}

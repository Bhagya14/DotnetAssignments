﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_13_Interface
{
    class Program
    {
        static void Main(string[] args)
        {
            productA objA = new productA(1, "oneplus", 35000);
            productB objB = new productB(2, "dell", 45000);

            Console.WriteLine("enter your name");
            string customername = Console.ReadLine();

            Order ord = new Order(customername);

            Console.WriteLine("enter product name:");
            string productname = Console.ReadLine();

            if (productname == "oneplus")
            {
                ord.addproduct(objA, 1);
            }
            else
            {
                ord.addproduct(objB, 2);
            }
            Console.WriteLine(ord.porderid);
            Console.WriteLine(ord.pcustomername);
            int ordervalue = ord.Getordervalue();
            Console.WriteLine("Total order value:" + ordervalue);
            Console.ReadLine();
        }
    }
}

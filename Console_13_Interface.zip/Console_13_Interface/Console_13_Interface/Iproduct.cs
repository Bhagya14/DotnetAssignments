﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_13_Interface
{
    interface Iorderproduct
    {
        int Getprice();
        int Getproductid();

    }
}

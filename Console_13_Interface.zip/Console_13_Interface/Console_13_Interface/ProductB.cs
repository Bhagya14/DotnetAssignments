﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_13_Interface
{
    class productB:Iorderproduct
    {
        private int PID;
        private string PName;
        private int Price;
        public productB(int PID, string PName, int Price)
        {
            this.PID = PID;
            this.PName = PName;
            this.Price = Price;
        }

        public int Getprice()
        {
            return this.Price;
        }

        public int Getproductid()
        {
            return this.PID;
        }
    }
}

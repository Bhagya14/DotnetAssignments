﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_task2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter account id:");
            int account_id = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("enter customer name:");
            string customer_name = Console.ReadLine();

            Console.WriteLine("customer address:");
            string customer_address = Console.ReadLine();

            Console.WriteLine("type of account:");
            string type = Console.ReadLine();

            Console.WriteLine("balance");
            int balance = Convert.ToInt32(Console.ReadLine());
            bool flag = true;
            while (flag)
            {
                Console.WriteLine(" deposit -1 ,withdraw -2,check balance-3,exit -4 ");
                int opt = Convert.ToInt32(Console.ReadLine());
                switch (opt)
                {
                    case 1:
                        {
                            Console.WriteLine("enter an amount:");
                            int deposit = Convert.ToInt32(Console.ReadLine());
                            if (deposit > 500)
                            {
                                balance = balance + deposit;
                                Console.WriteLine("amount:" + balance);
                            }
                            break;

                        }
                    case 2:
                        {
                            Console.WriteLine("enter amount to withdraw:");
                            int withdraw = Convert.ToInt32(Console.ReadLine());
                            if (balance > withdraw)
                            {
                                balance = balance - withdraw;
                                Console.WriteLine("remaining balance:" + balance);
                            }
                            else
                            {
                                Console.WriteLine("not sufficient");
                            }
                            break;
                        }
                    case 3:
                        {
                            Console.WriteLine("balance:" + balance);
                            break;
                        }
                    case 4:
                        {
                            flag = false;
                            break;
                        }


                }
            }
        }
    }
}

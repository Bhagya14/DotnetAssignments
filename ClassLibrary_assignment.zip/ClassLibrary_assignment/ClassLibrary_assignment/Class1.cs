﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary_assignment
{
    public class Class1
    {
        public int Getsum(int n1, int n2)
        {
            return n1 + n2;
        }
        public int Getmultiply(int n1, int n2)
        {
            return n1 * n2;
        }
        public int Getdivide(int n1, int n2)
        {
            return n1 / n2;
        }
        public int Getsubtract(int n1, int n2)
        {
            return n1 - n2;
        }
    }
}
